# hls_lfcd_lds_driver

[![GitHub version](https://badge.fury.io/gh/ROBOTIS-GIT%2Fhls_lfcd_lds_driver.svg)](https://badge.fury.io/gh/ROBOTIS-GIT%2Fhls_lfcd_lds_driver) [![Build Status](https://travis-ci.org/ROBOTIS-GIT/hls_lfcd_lds_driver.svg?branch=master)](https://travis-ci.org/ROBOTIS-GIT/hls_lfcd_lds_driver)

ROS package for HLDS HLS-LFCD LDS driver

# Documents
- ROS Wiki: http://wiki.ros.org/hls_lfcd_lds_driver
- ROBOTIS e-Manual: http://emanual.robotis.com/docs/en/platform/turtlebot3/appendix_lds_01
